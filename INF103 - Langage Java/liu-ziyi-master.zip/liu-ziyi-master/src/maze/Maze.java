package maze;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;

import dijkstra.GraphInterface;
import dijkstra.VertexInterface;

/**
 * Class {@code Maze} extends {@code GraphInterface}.
 */

public class Maze implements GraphInterface{
	
	private ArrayList<ArrayList<VertexInterface>> g=new ArrayList<ArrayList<VertexInterface>>();
	
	/**
	 * Constructor from graph g.
	 * @param g graph.
	 */
	public Maze(ArrayList<ArrayList<VertexInterface>> g) {
		this.g=g;
	}
	
	/**
	 * Constructor from file.
	 * @param fileName file path.
	 * @throws MazeReadingException when the file contains unknown label.
	 */
	public Maze(String fileName) throws MazeReadingException {
		this.initFromTextFile(fileName);
	}
	
	/**
	 * To achieve constructor from file.
	 * @param fileName file path.
	 * @throws MazeReadingException when the file contains unknown label.
	 */
	public final void initFromTextFile(String fileName) throws MazeReadingException {
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br=new BufferedReader(fr);
			String line;
			int y=0;
			while((line=br.readLine())!=null) {
				System.out.println(line);
				ArrayList<VertexInterface> l=new ArrayList<VertexInterface>();
				for(int x=0;x<line.length();x++) {
					switch(line.charAt(x)) {
					case 'E':
						EBox ebox=new EBox(x,y);
						VertexInterface box1=(VertexInterface) ebox;
						l.add(x,box1);
						break;
					case 'W':
						WBox wbox=new WBox(x,y);
						VertexInterface box2=(VertexInterface) wbox;
						l.add(x,box2);
						break;
					case 'A':
						ABox abox=new ABox(x,y);
						VertexInterface box3=(VertexInterface) abox;
						l.add(x,box3);
						break;
					case 'D':
						DBox dbox=new DBox(x,y);
						VertexInterface box4=(VertexInterface) dbox;
						l.add(x,box4);
						break;
					case 'S':
						SBox sbox=new SBox(x,y);
						VertexInterface box5=(VertexInterface) sbox;
						l.add(x,box5);
						break;
					default :
						String message=String.format("No Such Label at %d,%d", x+1, y+1);
						throw new MazeReadingException(message);
					}
				}
				g.add(y,l);
				y=y+1;
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Save maze to file.
	 * @param fileName file path.
	 */
	public final void saveToTextFile(String fileName) {
		try {
			FileWriter fw=new FileWriter(fileName);
			PrintWriter pw=new PrintWriter(fw);
			String s="";
			for(VertexInterface i : this.getAllVertices()) {
				s=s+i.getLabel();
				if(s.length()==10) {
					pw.println(s);
					pw.flush();
					s="";
				}
			}
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get number of vertex normal.
	 * @return number of vertex normal. 
	 */
	@Override
	public int getN() {
		int nb=0;
		for(VertexInterface i:this.getAllVertices()) {
			if(i.getLabel()!="W") {
				nb=nb+1;
			}
		}
		return nb;
	}
	
	/**
	 * Get dimension of maze.
	 * @return dimension of maze.
	 */
	public int getDim() {
		return g.get(0).size();
	}

	/**
	 * Get all vertices of maze.
	 * @return all vertices of maze.
	 */
	@Override
	public ArrayList<VertexInterface> getAllVertices() {
		ArrayList<VertexInterface> vertices=new ArrayList<VertexInterface>();
		for(ArrayList<VertexInterface> i:g) {
			for(VertexInterface s:i) {
				vertices.add(s);
			}
		}
		return vertices;
	}

	/**
	 * Get all vertices in maze who is not in set A.
	 * @param A set.
	 * @return all vertices in maze who is not in set A.
	 */
	@Override
	public ArrayList<VertexInterface> vertexsNotInA(HashSet<VertexInterface> A) {
		ArrayList<VertexInterface> v=new ArrayList<VertexInterface>();
		for(VertexInterface s: this.getAllVertices()) {
			if(!A.contains(s)) {
				v.add(s);
			}
		}
		return v;
	}

	/**
	 * Get the distance between two vertices.
	 * @param a vertex.
	 * @param b vertex.
	 * @return 1, the distance between two vertices neighboring.
	 */
	@Override
	public int getWeight(VertexInterface a, VertexInterface b) {
		return 1;
	}
	
	/**
	 * Set label M for box at (x,y).
	 * @param x position.
	 * @param y position.
	 */
	public void setXYM(int x,int y) {
		MBox m=new MBox(x,y);
		m.setLabel("M");
		g.get(y).set(x,m);
	}
	
	/**
	 * Get all successors of vertex.
	 * @param s vertex.
	 * @return all successors of s.
	 */
	@Override
	public ArrayList<VertexInterface> getSuccessors(VertexInterface s) {
		//if(s.getLabel()=="W") {
			//return null;
		//}else {
			ArrayList<VertexInterface> v=new ArrayList<VertexInterface>();
			int x=0;
			int y=0;
			for(ArrayList<VertexInterface> i:g) {
				x=i.indexOf(s);
				y=g.indexOf(i);
				if(x!=-1) {
					break;
				}
			}
			int N=this.getDim();
			if(x-1>=0) {
				if(g.get(y).get(x-1).getLabel()!="W") {
					v.add(g.get(y).get(x-1));
				}
			}
			if(x+1<N) {
				if(g.get(y).get(x+1).getLabel()!="W") {
					v.add(g.get(y).get(x+1));
				}
			}
			if(y-1>=0) {
				if(g.get(y-1).get(x).getLabel()!="W") {
					v.add(g.get(y-1).get(x));
				}
			}
			if(y+1<N) {
				if(g.get(y+1).get(x).getLabel()!="W") {
					v.add(g.get(y+1).get(x));
				}
			}
			
			return v;
		}
	//}
	
	/**
	 * Get graph g.
	 * @return graph g.
	 */
	public ArrayList<ArrayList<VertexInterface>> getG() {
		return g;
	}

}
