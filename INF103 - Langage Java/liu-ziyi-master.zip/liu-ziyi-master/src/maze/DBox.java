package maze;

/**
 * Class {@code DBox} extends {@code MBox}.
 * Box departure, label D, color red.
 */

public class DBox extends MBox{

	/**
	 * Constructor.
	 * @param x position.
	 * @param y position.
	 */
	public DBox(int x, int y) {
		super(x, y);
		super.setColor("red");
		super.setLabel("D");
	}

}
