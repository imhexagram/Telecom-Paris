package maze;

/**
 * Class {@code ABox} extends {@code MBox}.
 * Box arrive, label A, color red.
 */

public class ABox extends MBox{

	/**
	 * Constructor.
	 * @param x position.
	 * @param y position.
	 */
	public ABox(int x, int y) {
		super(x, y);
		super.setColor("red");
		super.setLabel("A");
	}

}
