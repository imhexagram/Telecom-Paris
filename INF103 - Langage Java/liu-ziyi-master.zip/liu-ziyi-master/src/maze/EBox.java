package maze;

/**
 * Class {@code EBox} extends {@code MBox}.
 * Box normal, label E, color green.
 */

public class EBox extends MBox{

	/**
	 * Constructor.
	 * @param x position.
	 * @param y position.
	 */
	public EBox(int x, int y) {
		super(x, y);
		super.setColor("green");
		super.setLabel("E");
	}

}
