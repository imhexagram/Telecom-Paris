package maze;


/**
 * Class {@code MazeReadingException} extends {@link Exception}.
 * Thrown when the file doesn't follow the rules.
 */

public class MazeReadingException extends Exception{

	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor.
	 */
	public MazeReadingException() {
		super();
	}
	
	/**
	 * Constructor.
	 * @param message exception message.
	 */
	public MazeReadingException(String message) {
		super(message);
		
	}

}
