package maze;

import dijkstra.VertexInterface;

/**
 * Class {@code MBox} implements {@code VertexInterface}.
 * Box model
 */

public class MBox implements VertexInterface{
	
	private int x;
	private int y;
	private String color;
	private String label;
	
	/**
	 * Constructor.
	 * @param x position.
	 * @param y position.
	 */
	public MBox(int x, int y) {
		this.x=x;
		this.y=y;
	}
	
	/**
	 * Get position.
	 * @return position.
	 */
	public int[] getPosition() {
		int[] p= {this.x,this.y};
		return(p);
	}
	
	/**
	 * Get x position.
	 * @return x position.
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * Get y position.
	 * @return y position.
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * Get label.
	 * @return label.
	 */
	public String getLabel() {
		return label;
	}
	
	/**
	 * Get color.
	 * @return color.
	 */
	public String getColor() {
		return color;
	}
	
	/**
	 * Set label.
	 * @param label label.
	 */
	public void setLabel(String label) {
		this.label=label;
	}

	/**
	 * Set color.
	 * @param color color.
	 */
	public void setColor(String color) {
		this.color=color;
	}

	

}
