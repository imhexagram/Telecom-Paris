package maze;

/**
 * Class {@code SBox} extends {@code MBox}.
 * Box solution, label S, color blue.
 */

public class SBox extends MBox{

	/**
	 * Constructor.
	 * @param x position.
	 * @param y position.
	 */
	public SBox(int x, int y) {
		super(x, y);
		super.setColor("blue");
		super.setLabel("S");
	}
}
