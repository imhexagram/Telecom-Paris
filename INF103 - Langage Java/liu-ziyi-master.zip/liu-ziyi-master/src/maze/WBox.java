package maze;

/**
 * Class {@code WBox} extends {@code MBox}.
 * Box wall, label W, color gray.
 */

public class WBox extends MBox{

	/**
	 * Constructor.
	 * @param x position.
	 * @param y position.
	 */
	public WBox(int x, int y) {
		super(x, y);
		super.setColor("gray");
		super.setLabel("W");
	}

}
