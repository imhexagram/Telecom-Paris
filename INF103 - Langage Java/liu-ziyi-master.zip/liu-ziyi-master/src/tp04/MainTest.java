package tp04;

import dijkstra.*;
import graphical.*;
import maze.*;

/**
 * Class {@code MainTest} main function.
 */

public class MainTest {

	public static void main(String[] args) throws MazeReadingException {
		//Maze maze=new Maze("data/labyrinthe");
		
		//System.out.println(maze.getAllVertices().toString());
		/*
		for(VertexInterface i : maze.getAllVertices()) {
			System.out.println(i.getLabel());
		}
		*/
		//maze.saveToTextFile("data/labyrinthe2");
		
		/*
		PreviousInterface p = null;
		for(VertexInterface v:maze.getAllVertices()) {
			if(v.getLabel()=="D") {
				Dijkstra d=new Dijkstra();
				p=Dijkstra.dijkstra(maze, v);
				System.out.println(p);
				break;
			}
		}
		
		for(VertexInterface v:maze.getAllVertices()) {
			if(v.getLabel()=="A") {
				VertexInterface a=v;
				while(p.get(a)!=null) {
					//System.out.println(p.get(a));
					if(p.get(a).getLabel()!="D") {
						p.get(a).setLabel("S");
					}
					a=p.get(a);
				}
			}
		}
		maze.saveToTextFile("data/labyrinthe3");
		*/
		
		new LabyrintheApp();

	}

}
