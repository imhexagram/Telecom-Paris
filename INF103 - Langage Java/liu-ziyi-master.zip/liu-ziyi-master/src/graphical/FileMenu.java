package graphical;

import javax.swing.*;

/**
 * Class {@code FileMenu} extends {@link JMenu}.
 */

public class FileMenu extends JMenu{
	
	private final QuitMenuItem quitMenuItem;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheApp.
	 */
	public FileMenu(LabyrintheApp labApp) {
		super("File");
		add(quitMenuItem=new QuitMenuItem(labApp));
	}

}
