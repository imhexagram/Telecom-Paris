package graphical;

import javax.swing.*;

/**
 * Class {@code ButtonsPanel} extends {@link JPanel}.
 * Panel for buttons.
 */
public class ButtonsPanel extends JPanel{
	
	private final GoButton goButton;
	private final ModeButton modeButton;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheApp.
	 */
	public ButtonsPanel(LabyrintheApp labApp) {
		add(modeButton=new ModeButton(labApp));
		add(goButton=new GoButton(labApp));
	}

	/**
	 * When update.
	 */
	public void notifyForUpdate() {
		goButton.notifyForUpdate();
	}
}
