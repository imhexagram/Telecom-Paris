package graphical;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Class {©{@code Box} extends {@link JPanel} implements {@link MouseListener}.
 * Box in BoxPanel, performance maze.
 *
 */
public class Box extends JPanel implements MouseListener{
	
	private final LabyrintheApp labApp;
	private Color color;
	private String label;
	private static int nbBoxRed=2;
	private static int nbDBox=1;
	private static int nbABox=1;
	
	/**
	 * Constructor of Box
	 * @param labApp LabyrintheApp.
	 * @param label label of Box.
	 */
	public Box(LabyrintheApp labApp,String label) {
		this.labApp=labApp;
		this.label=label;
		setPreferredSize(new Dimension(50,50));
		switch(this.label) {
		case "E":
			color=Color.green;
			break;
		case "D":
			color=Color.red;
			break;
		case "A":
			color=Color.red;
			break;
		case "W":
			color=Color.gray;
			break;
		case "S":
			color=Color.blue;
			break;
		default:
			color=Color.white;
		}
		setBackground(color);
		addMouseListener(this);
	}

	/**
	 * When update.
	 */
	public void notifyForUpdate() {
		repaint();
	}
	
	/**
	 * When mouse click. If at model DA, change label and color for DBox and ABox. If at model Wall, change label and color for WBox and EBox.
	 * No more than two red Box (ABox and DBox).
	 */
	@Override
	public void mouseClicked(MouseEvent arg0) {
		if(labApp.getLabAppModel().getMode()=="DA") {
			if(color!=Color.gray) {
				if(color!=Color.red & nbBoxRed<2) {
					color=Color.red;
					nbBoxRed++;
					if(nbDBox==0) {
						this.label="D";
						labApp.getLabAppModel().setBoxLabel(this,"D");
						nbDBox++;
					}else {
						this.label="A";
						labApp.getLabAppModel().setBoxLabel(this,"A");
						nbABox++;
					}
					
				}else{
					if(color==Color.red) {
						nbBoxRed--;
						if(this.label=="D") {
							nbDBox--;
						}
						if(this.label=="A") {
							nbABox--;
						}
					}
					color=Color.green;
					labApp.getLabAppModel().setBoxLabel(this,"E");
				}
				setBackground(color);
			}
		}else {
			if(color!=Color.red) {
				if(color==Color.gray) {
					color=Color.green;
					this.label="E";
					labApp.getLabAppModel().setBoxLabel(this, "E");
				}else {
					color=Color.gray;
					this.label="W";
					labApp.getLabAppModel().setBoxLabel(this, "W");
				}
			}
		}
		
	}

	/**
	 * Indicator when mouse entered. 
	 */
	@Override
	public void mouseEntered(MouseEvent arg0) {
		if(labApp.getLabAppModel().getMode()=="DA") {
			if(color!=color.gray) {
				setBackground(Color.yellow);
			}
		}else {
			if(color!=color.red) {
				setBackground(Color.darkGray);
			}
		}
	}

	/**
	 * Indicator when mouse exited.
	 */
	@Override
	public void mouseExited(MouseEvent arg0) {
		setBackground(color);
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		
	}
	
	/**
	 * Set color and label.
	 * @param color color.
	 * @param label label.
	 */
	public void setColorAndLabel(Color color, String label) {
		this.color=color;
		this.label=label;
	}
	

}
