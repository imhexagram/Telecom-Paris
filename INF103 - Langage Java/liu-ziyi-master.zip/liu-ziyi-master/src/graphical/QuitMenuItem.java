package graphical;

import java.awt.event.*;

import javax.swing.*;

/**
 * Class {@code QuitMenuItem} extends {@link JMenuItem} implements {@link ActionListener}.
 */

public class QuitMenuItem extends JMenuItem implements ActionListener{

	private final LabyrintheApp labApp;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheAPP.
	 */
	public QuitMenuItem(LabyrintheApp labApp) {
		super("Quit");
		this.labApp=labApp;
		addActionListener(this);
	}
	
	/**
	 * When click quit, and maze was modified, chose whether to save.
	 */
	public void actionPerformed(ActionEvent evt) {
		LabyrintheAppModel labAppModel=labApp.getLabAppModel();
		if(labAppModel.isModified()) {
			int reponse=JOptionPane.showInternalOptionDialog(this, 
															 "Labyrinthe not saved. Save it ?", 
															 "Quit application", 
															 JOptionPane.YES_NO_CANCEL_OPTION, 
															 JOptionPane.WARNING_MESSAGE, 
															 null, null, null);
			switch(reponse) {
			case JOptionPane.CANCEL_OPTION:
				return;
			case JOptionPane.OK_OPTION:
				labAppModel.saveToFile();
				break;
			case JOptionPane.NO_OPTION:
				break;
			}
		}
		System.exit(0);
	}

}
