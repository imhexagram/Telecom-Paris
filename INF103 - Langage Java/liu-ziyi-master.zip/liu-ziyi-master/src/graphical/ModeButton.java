package graphical;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * Class {@code ModeButton} extends {@link JButton} extends {@link ActionListener}.
 * Button for change mode DA/Wall.
 */

public class ModeButton extends JButton implements ActionListener{

private final LabyrintheApp labApp;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheApp.
	 */
	public ModeButton(LabyrintheApp labApp) {
		super("Change Mode (DA/Wall)");
		this.labApp=labApp;
		addActionListener(this);
	}
	
	/**
	 * When click, switch between two mode DA/Wall.s
	 */
	public final void actionPerformed(ActionEvent evt)  {
		labApp.getLabAppModel().changeMode();
		System.out.println("Change Mode to : " + labApp.getLabAppModel().getMode());
	}

	/**
	 * When update.
	 */
	public void notifyForUpdate() {
		
	}
}

