package graphical;

import java.awt.*;
import maze.*;

import javax.swing.*;
import dijkstra.VertexInterface;

/**
 * Class {@code BoxPanel} extends {@link JPanel}.
 * Panel 10*10 for boxes.
 */

public class BoxPanel extends JPanel{
	
	private Box box;
	private LabyrintheApp labApp;
	
	/**
	 * Constructor, initialize maze.
	 * @param labApp LAbyrintheAPP.
	 * @throws MazeReadingException when the file contains unknown label.
	 */
	public BoxPanel(LabyrintheApp labApp) throws MazeReadingException {
		this.labApp=labApp; 
		setLayout(new GridLayout(10,10)); 
		Maze maze=labApp.getLabAppModel().getMaze(); 
		for(VertexInterface v:maze.getAllVertices()) {
			add(box=new Box(labApp,v.getLabel())); 
		}
	}
	
	/**
	 * Get box from position.
	 * @param x position.
	 * @param y position.
	 * @return Box at (x,y).
	 */
	public Box getBoxAt(int x,int y) {
		Box b=(Box)this.getComponentAt(x*50, y*50);
		return b;
	}

	/**
	 * When update.
	 */
	public void notifyForUpdate(){
		repaint();
		box.notifyForUpdate();
	}

}
