package graphical;

import javax.swing.*;
import javax.swing.event.*;

import maze.MazeReadingException;

/**
 * Class {@code LabyrintheApp} extends {@link JFrame} implements {@link ChangeListener}.
 * The App.
 */
public class LabyrintheApp extends JFrame implements ChangeListener{
	
	private final MenuBar menuBar;
	private final WindowPanel windowPanel;
	private LabyrintheAppModel labAppModel=new LabyrintheAppModel(this);
	
	/**
	 * Constructor.
	 * @throws MazeReadingException
	 */
	public LabyrintheApp() throws MazeReadingException {
		super("Labyrinthe Application");
		labAppModel.setMaze();
		setJMenuBar(menuBar=new MenuBar(this));
		setContentPane(windowPanel=new WindowPanel(this));
		labAppModel.addObserver(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}
	
	/**
	 * Get LabyrintheAppModel.
	 * @return LabyrintheAppModel.
	 */
	public LabyrintheAppModel getLabAppModel() {
		return labAppModel;
	}
	
	/**
	 * Get window Panel.
	 * @return WindowPanel.
	 */
	public WindowPanel getWindowPanel() {
		return windowPanel;
	}
	
	/**
	 * Set LabyrintheAppModel.
	 * @param labAppModel LabyrintheAppModel.
	 */
	public void setLabAppModel(LabyrintheAppModel labAppModel) {
		this.labAppModel=labAppModel;
	}
	
	/**
	 * When update.
	 */
	public void stateChanged(ChangeEvent evt) {
		windowPanel.notifyForUpdate();
	};

}
