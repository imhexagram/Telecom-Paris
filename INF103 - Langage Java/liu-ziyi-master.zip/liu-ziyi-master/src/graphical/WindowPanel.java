package graphical;

import java.awt.*;

import javax.swing.*;

import maze.MazeReadingException;

/**
 * Class {@code WindowPanel} extends {@link JPanel}.
 */

public class WindowPanel extends JPanel{
	
	private final BoxPanel boxPanel;
	private final ButtonsPanel buttonsPanel;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheAPP.
	 * @throws MazeReadingException when the file contains unknown label.
	 */
	public WindowPanel(LabyrintheApp labApp) throws MazeReadingException {
		setLayout(new BorderLayout());
		add(boxPanel=new BoxPanel(labApp),BorderLayout.CENTER);
		add(buttonsPanel=new ButtonsPanel(labApp),BorderLayout.SOUTH);
	}

	/**
	 * When update.
	 */
	public void notifyForUpdate(){
		boxPanel.notifyForUpdate();
		buttonsPanel.notifyForUpdate();
	}
	
	/**
	 * Get BoxPanel.
	 * @return BoxPanel.
	 */
	public BoxPanel getBoxPanel() {
		return boxPanel;
	}

}
