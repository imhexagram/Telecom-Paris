package graphical;

import java.awt.event.*;

import javax.swing.*;

import maze.MazeReadingException;

/**
 * Class {@code GoButton} extends {@link JButton} implements {@link ActionListener}.
 */

public class GoButton extends JButton implements ActionListener{
	
	private final LabyrintheApp labApp;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheApp.
	 */
	public GoButton(LabyrintheApp labApp) {
		super("Go!");
		this.labApp=labApp;
		addActionListener(this);
	}
	
	/**
	 * When click, lance algorithm of Dijkstra.
	 */
	public final void actionPerformed(ActionEvent evt)  {
		try {
			labApp.getLabAppModel().goDijkstra();
			System.out.println("GO!");
		} catch (MazeReadingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * When update.
	 */
	public void notifyForUpdate() {
		
	}
}
