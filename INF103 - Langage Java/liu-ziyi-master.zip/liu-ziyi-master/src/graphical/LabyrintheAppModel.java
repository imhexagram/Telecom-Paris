package graphical;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.event.*;

import dijkstra.*;
import maze.*;

/**
 * Class {@code LabyrintheAppModel}, model of App, achieve functions.
 */
public class LabyrintheAppModel {
	
	private Maze maze=null;
	private boolean modified=false;
	private LabyrintheApp labApp;
	private String mode="DA";
	private ArrayList<ChangeListener> listeners=new ArrayList<ChangeListener>();
	
	/**
	 * Constructor.
	 * @param labyrintheApp LabyrintheApp.
	 */
	public LabyrintheAppModel(LabyrintheApp labyrintheApp) {
		this.labApp=labyrintheApp;
	}

	/**
	 * Add observer.
	 * @param listener listener.
	 */
	public void addObserver(ChangeListener listener) {
		listeners.add(listener);
	}
	
	/**
	 * When update.
	 */
	public void stateChanges() {
		ChangeEvent evt=new ChangeEvent(this);
		for(ChangeListener listener:listeners) {
			listener.stateChanged(evt);
		}
	}

	/**
	 * Lance Dijkstra. Change Boxes and Vertices states.
	 * @throws MazeReadingException
	 */
	public void goDijkstra() throws MazeReadingException {
		for(VertexInterface v:maze.getAllVertices()) {
			if(v.getLabel()=="S") {
				v.setLabel("E");
				MBox mbox=(MBox) v;
				int x=mbox.getX();
				int y=mbox.getY();
				this.labApp.getWindowPanel().getBoxPanel().getComponentAt(50*x, 50*y).setBackground(Color.green);
				this.labApp.getWindowPanel().getBoxPanel().getBoxAt(x, y).setColorAndLabel(Color.green,"E");
			}
		}
		
		PreviousInterface p = null;
		for(VertexInterface v:maze.getAllVertices()) {
			if(v.getLabel()=="D") {
				p=Dijkstra.dijkstra(maze, v);
				break;
			}
		}
		for(VertexInterface v:maze.getAllVertices()) {
			if(v.getLabel()=="A") {
				VertexInterface a=v;
				while(p.get(a)!=null) {
					if(p.get(a).getLabel()!="D") {
						System.out.println(p.get(a));
						p.get(a).setLabel("S");
						MBox mbox=(MBox) p.get(a);
						int x=mbox.getX();
						int y=mbox.getY();
						this.labApp.getWindowPanel().getBoxPanel().getComponentAt(50*x, 50*y).setBackground(Color.blue);
						this.labApp.getWindowPanel().getBoxPanel().getBoxAt(x, y).setColorAndLabel(Color.blue,"S");
						a=p.get(a);
					}else {
						break;
					}
				}
				break;
			}
		}
		this.saveToFile();
		modified=true;
		stateChanges();
	}
	
	/**
	 * Determine if maze has been modified.
	 * @return {@code true} if modified.
	 */
	public boolean isModified() {
		return modified;
	}
	
	/**
	 * Set Box label.
	 * @param box box.
	 * @param label label.
	 */
	public void setBoxLabel(Box box, String label) {
		int x=box.getX()/50;
		int y=box.getY()/50;
		maze.getG().get(y).get(x).setLabel(label);
		this.saveToFile();
		modified=true;
		stateChanges();
	}

	/**
	 * Save maze to "data/labyrinthe_autosave"
	 */
	public void saveToFile() {
		maze.saveToTextFile("data/labyrinthe_autosave");
	}

	/**
	 * Set maze from "data/labyrinthe".
	 */
	public void setMaze() {
		try {
			this.maze=new Maze("data/labyrinthe");
		} catch (MazeReadingException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Get maze.
	 * @return maze.
	 */
	public Maze getMaze() {
		return this.maze;
	}
	
	/**
	 * Change operation mode DA for DBox and ABox or Wall for WBox and EBox.
	 */
	public void changeMode() {
		if(this.mode=="DA") {
			this.mode="Wall";
		}else {
			this.mode="DA";
		}
	}
	
	/**
	 * Get mode.
	 * @return mode.
	 */
	public String getMode() {
		return this.mode;
	}
	
	
	
}
