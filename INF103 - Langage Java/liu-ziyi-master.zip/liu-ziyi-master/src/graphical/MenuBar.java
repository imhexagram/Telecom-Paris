package graphical;

import javax.swing.*;

/**
 * Class {@code MenuBar} extends {@link JMenuBar}.
 */
public class MenuBar extends JMenuBar{
	
	private final FileMenu fileMenu;
	
	/**
	 * Constructor.
	 * @param labApp LabyrintheApp.
	 */
	public MenuBar(LabyrintheApp labApp) {
		super();
		add(fileMenu=new FileMenu(labApp));
	}

}
