package dijkstra;

import java.util.ArrayList;
import java.util.HashSet;


/**
 * Interface {@code GraphInterface} for operate graph.
 */

public interface GraphInterface {

	
	public int getN(); //number of vertices
	public ArrayList<VertexInterface> getAllVertices(); //return list of vertices in graph
	public ArrayList<VertexInterface> vertexsNotInA(HashSet<VertexInterface> A); // return list of vertices who is not in set A
	public int getWeight(VertexInterface a, VertexInterface b); //return distance between vertex a and vertex b
	public ArrayList<VertexInterface> getSuccessors(VertexInterface x); //return successors of vertex x
}
