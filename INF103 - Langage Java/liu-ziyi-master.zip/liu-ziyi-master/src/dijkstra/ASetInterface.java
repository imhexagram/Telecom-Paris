package dijkstra;

import java.util.HashSet;

/**
 * Interface {@code ASetInterface} for operate set.
 */
public interface ASetInterface {
	
	public void add(VertexInterface r); // add vertex r in set a
	public boolean isInA(VertexInterface r); // check r in set a
	public HashSet<VertexInterface> getA(); //return set a
	public void clear(); //remove all vertex in set a

}
