package dijkstra;

import java.util.HashSet;

/**
 * Class {@code ASet} implements {@code ASetInterface}.
 * Use {@link java.util.HashSet} for store Vertex.
 */


public class ASet implements ASetInterface{
	
	private HashSet<VertexInterface> A=new HashSet<VertexInterface>();

	/**
	 * Add vertex in this set.
	 * @param r vertex.
	 */
	@Override
	public void add(VertexInterface r) {
		A.add(r);
		
	}

	/**
	 * Determine if vertex is in set.
	 * @param r vertex.
	 * @return {@code true} if @param r the {@code VertexInterface} is in this set.
	 */
	@Override
	public boolean isInA(VertexInterface r) {
		return A.contains(r);
	}

	/**
	 * Get set.
	 * @return {@code HashSet<VertexInterface>} this set.
	 */
	@Override
	public HashSet<VertexInterface> getA() {
		return A;
	}
	
	/**
	 * Remove all {@code VertexInterface} in this set.
	 */
	public void clear() {
		this.A =new HashSet<VertexInterface>();
	}

}
