package dijkstra;

/**
 * Interface {@code PiInterface} for operate dictionary of distance.
 */

public interface PiInterface {
	public void set(VertexInterface r, int x); //set distance for vertex
	public int get(VertexInterface r); //get distance of vertex

}
