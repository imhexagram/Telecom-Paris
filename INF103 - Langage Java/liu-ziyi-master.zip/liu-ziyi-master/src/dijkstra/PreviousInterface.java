package dijkstra;

/**
 * Interface {@code PreviousInterface} for operate dictionary of previous.
 */

public interface PreviousInterface {
	public void set(VertexInterface y, VertexInterface p); //set previous
	public VertexInterface get(VertexInterface y); //get previous
}
