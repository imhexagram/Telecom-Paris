package dijkstra;

/**
 * Interface {@code VertexInterface} operate vertex.
 */
public interface VertexInterface {
	
	public String getLabel(); //get label
	public void setLabel(String label); //set label

}
