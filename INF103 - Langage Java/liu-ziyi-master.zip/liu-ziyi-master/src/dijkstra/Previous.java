package dijkstra;

import java.util.Hashtable;

/**
 * Class {@code Previous} implements {@code PreviousInterface}.
 * Dictionary of vertex and its previous vertex.
 */
public class Previous implements PreviousInterface{
	
	private Hashtable<VertexInterface, VertexInterface> m=new Hashtable<VertexInterface, VertexInterface>();

	/**
	 * Set previous of vertex.
	 * @param y vertex.
	 * @param p previous of vertex.
	 */
	@Override
	public void set(VertexInterface y, VertexInterface p) {
		m.put(y, p);
	}

	/**
	 * Get previous of vertex.
	 * @param y vertex.
	 * @return previous of vertex.
	 */
	@Override
	public VertexInterface get(VertexInterface y) {
		return m.get(y);
	}

}
