package dijkstra;

import java.util.ArrayList;

/**
 * Class {@code Dijkstra} to achieve algorithm Dijkstra.
 */

public class Dijkstra{
	
	private static ASet a=new ASet();
	private static Previous previous=new Previous();
	private static Pi pi=new Pi();
	
	/**
	 * Calculate previous by algorithm Dijkstra.
	 * @param g Graph.
	 * @param r root vertex.
	 * @return dictionary vertex,previous.
	 */
	public static PreviousInterface dijkstra(GraphInterface g, VertexInterface r) {
		return dijkstra(g,r,a,pi,previous);
	}
	
	/**
	 * Calculate previous by algorithm Dijkstra.
	 * @param g Graph.
	 * @param r root vertex.
	 * @param a set for vertices analyzed.
	 * @param pi dictionary vertex,distance from root.
	 * @param previous dictionary vertex,previous.
	 * @return @param previous.
	 */
	private static PreviousInterface dijkstra (
			GraphInterface g, 
			VertexInterface r, 
			ASetInterface a, 
			PiInterface pi, 
			PreviousInterface previous) {
		int n=g.getN();
		a.clear();
		a.add(r);
		VertexInterface key=r;
		for (VertexInterface s:g.getAllVertices()) {
			pi.set(s,Integer.MAX_VALUE);
		}
		pi.set(r,0);
		for (int j=1;j<n-1;j++) {
			ArrayList<VertexInterface> sucessors=g.getSuccessors(key);
			ArrayList<VertexInterface> B=g.vertexsNotInA(a.getA());
			for (VertexInterface y:sucessors) {
				if(B.contains(y)) {
					if (pi.get(key)+g.getWeight(key, y)<pi.get(y)) {
						pi.set(y,pi.get(key)+g.getWeight(key, y));
						previous.set(y,key);
					}
				}
			}
			int min=Integer.MAX_VALUE;
			VertexInterface minVertex = null;
			for(VertexInterface y : B) {
				if(pi.get(y)<min) {
					min=pi.get(y);
					minVertex=y;
				}
			}
			key=minVertex;
			a.add(key);
		}
		return previous;
	}

	public static void main(String[] args) {
		//System.out.println(System.getProperty("user.dir"));
		
	}
}
