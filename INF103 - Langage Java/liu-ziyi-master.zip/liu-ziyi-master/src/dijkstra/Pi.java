package dijkstra;

import java.util.Hashtable;

/**
 * Class {@code Pi} implements {@code PiInterface}.
 * Dictionary of vertex and its distance from root vertex.
 */
public class Pi implements PiInterface{
	
	private Hashtable<VertexInterface, Integer> m=new Hashtable<VertexInterface, Integer>();
	
	/**
	 * Set distance from root vertex for vertex.
	 * @param r vertex.
	 * @param x distance.
	 */
	@Override
	public void set(VertexInterface r, int x) {
		m.put(r, x);
	}

	/**
	 * get distance from root of vertex.
	 * @param r vertex.
	 * @return distance from root vertex of vertex.
	 */
	@Override
	public int get(VertexInterface r) {
		return m.get(r);
	}

}
